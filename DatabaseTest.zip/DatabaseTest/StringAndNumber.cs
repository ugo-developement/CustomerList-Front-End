﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseTest
{
    class StringAndNumber
    {
        public string title;
        public int count;

        public StringAndNumber(string title, int count)
        {
            this.title = title;
            this.count = count;
        }

        
    }
}
